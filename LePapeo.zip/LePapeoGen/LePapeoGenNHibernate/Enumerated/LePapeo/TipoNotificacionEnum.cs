
using System;

namespace LePapeoGenNHibernate.Enumerated.LePapeo
{
public enum TipoNotificacionEnum { nuevaReserva=1, recordatorioReserva=2, nuevoRestaurante=3 };
}
