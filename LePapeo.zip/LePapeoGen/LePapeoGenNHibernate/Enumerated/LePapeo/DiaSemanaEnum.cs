
using System;

namespace LePapeoGenNHibernate.Enumerated.LePapeo
{
public enum DiaSemanaEnum { lunes=1, martes=2, miercoles=3, jueves=4, viernes=5, sabado=6, domingo=7 };
}
