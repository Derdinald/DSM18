
using System;
using System.Text;
using LePapeoGenNHibernate.CEN.LePapeo;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.Exceptions;


/*
 * Clase Opinion:
 *
 */

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial class OpinionCAD : BasicCAD, IOpinionCAD
{
public OpinionCAD() : base ()
{
}

public OpinionCAD(ISession sessionAux) : base (sessionAux)
{
}



public OpinionEN ReadOIDDefault (int id
                                 )
{
        OpinionEN opinionEN = null;

        try
        {
                SessionInitializeTransaction ();
                opinionEN = (OpinionEN)session.Get (typeof(OpinionEN), id);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return opinionEN;
}

public System.Collections.Generic.IList<OpinionEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<OpinionEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(OpinionEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<OpinionEN>();
                        else
                                result = session.CreateCriteria (typeof(OpinionEN)).List<OpinionEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (OpinionEN opinion)
{
        try
        {
                SessionInitializeTransaction ();
                OpinionEN opinionEN = (OpinionEN)session.Load (typeof(OpinionEN), opinion.Id);

                opinionEN.Valoracion = opinion.Valoracion;


                opinionEN.Titulo = opinion.Titulo;


                opinionEN.Comentario = opinion.Comentario;



                session.Update (opinionEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int New_ (OpinionEN opinion)
{
        try
        {
                SessionInitializeTransaction ();
                if (opinion.Registrado != null) {
                        // Argumento OID y no colección.
                        opinion.Registrado = (LePapeoGenNHibernate.EN.LePapeo.RegistradoEN)session.Load (typeof(LePapeoGenNHibernate.EN.LePapeo.RegistradoEN), opinion.Registrado.Id);

                        opinion.Registrado.Opinion
                        .Add (opinion);
                }
                if (opinion.Restaurante != null) {
                        // Argumento OID y no colección.
                        opinion.Restaurante = (LePapeoGenNHibernate.EN.LePapeo.RestauranteEN)session.Load (typeof(LePapeoGenNHibernate.EN.LePapeo.RestauranteEN), opinion.Restaurante.Id);

                        opinion.Restaurante.Opinion_0
                        .Add (opinion);
                }

                session.Save (opinion);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return opinion.Id;
}

public void Modify (OpinionEN opinion)
{
        try
        {
                SessionInitializeTransaction ();
                OpinionEN opinionEN = (OpinionEN)session.Load (typeof(OpinionEN), opinion.Id);

                opinionEN.Valoracion = opinion.Valoracion;


                opinionEN.Titulo = opinion.Titulo;


                opinionEN.Comentario = opinion.Comentario;

                session.Update (opinionEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                OpinionEN opinionEN = (OpinionEN)session.Load (typeof(OpinionEN), id);
                session.Delete (opinionEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: ReadOID
//Con e: OpinionEN
public OpinionEN ReadOID (int id
                          )
{
        OpinionEN opinionEN = null;

        try
        {
                SessionInitializeTransaction ();
                opinionEN = (OpinionEN)session.Get (typeof(OpinionEN), id);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return opinionEN;
}

public System.Collections.Generic.IList<OpinionEN> ReadAll (int first, int size)
{
        System.Collections.Generic.IList<OpinionEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(OpinionEN)).
                                 SetFirstResult (first).SetMaxResults (size).List<OpinionEN>();
                else
                        result = session.CreateCriteria (typeof(OpinionEN)).List<OpinionEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in OpinionCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
