
using System;
using System.Text;
using LePapeoGenNHibernate.CEN.LePapeo;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.Exceptions;


/*
 * Clase HorarioSemana:
 *
 */

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial class HorarioSemanaCAD : BasicCAD, IHorarioSemanaCAD
{
public HorarioSemanaCAD() : base ()
{
}

public HorarioSemanaCAD(ISession sessionAux) : base (sessionAux)
{
}



public HorarioSemanaEN ReadOIDDefault (int id
                                       )
{
        HorarioSemanaEN horarioSemanaEN = null;

        try
        {
                SessionInitializeTransaction ();
                horarioSemanaEN = (HorarioSemanaEN)session.Get (typeof(HorarioSemanaEN), id);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioSemanaCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return horarioSemanaEN;
}

public System.Collections.Generic.IList<HorarioSemanaEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<HorarioSemanaEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(HorarioSemanaEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<HorarioSemanaEN>();
                        else
                                result = session.CreateCriteria (typeof(HorarioSemanaEN)).List<HorarioSemanaEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioSemanaCAD.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (HorarioSemanaEN horarioSemana)
{
        try
        {
                SessionInitializeTransaction ();
                HorarioSemanaEN horarioSemanaEN = (HorarioSemanaEN)session.Load (typeof(HorarioSemanaEN), horarioSemana.Id);

                horarioSemanaEN.Lunes = horarioSemana.Lunes;


                horarioSemanaEN.Martes = horarioSemana.Martes;


                horarioSemanaEN.Miercoles = horarioSemana.Miercoles;


                horarioSemanaEN.Jueves = horarioSemana.Jueves;


                horarioSemanaEN.Viernes = horarioSemana.Viernes;


                horarioSemanaEN.Sabado = horarioSemana.Sabado;


                horarioSemanaEN.Domingo = horarioSemana.Domingo;



                session.Update (horarioSemanaEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioSemanaCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int New_ (HorarioSemanaEN horarioSemana)
{
        try
        {
                SessionInitializeTransaction ();

                session.Save (horarioSemana);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioSemanaCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return horarioSemana.Id;
}

public void Modify (HorarioSemanaEN horarioSemana)
{
        try
        {
                SessionInitializeTransaction ();
                HorarioSemanaEN horarioSemanaEN = (HorarioSemanaEN)session.Load (typeof(HorarioSemanaEN), horarioSemana.Id);

                horarioSemanaEN.Lunes = horarioSemana.Lunes;


                horarioSemanaEN.Martes = horarioSemana.Martes;


                horarioSemanaEN.Miercoles = horarioSemana.Miercoles;


                horarioSemanaEN.Jueves = horarioSemana.Jueves;


                horarioSemanaEN.Viernes = horarioSemana.Viernes;


                horarioSemanaEN.Sabado = horarioSemana.Sabado;


                horarioSemanaEN.Domingo = horarioSemana.Domingo;

                session.Update (horarioSemanaEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioSemanaCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                HorarioSemanaEN horarioSemanaEN = (HorarioSemanaEN)session.Load (typeof(HorarioSemanaEN), id);
                session.Delete (horarioSemanaEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioSemanaCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
}
}
