
using System;
using System.Text;
using LePapeoGenNHibernate.CEN.LePapeo;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.Exceptions;


/*
 * Clase Restaurante:
 *
 */

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial class RestauranteCAD : BasicCAD, IRestauranteCAD
{
public RestauranteCAD() : base ()
{
}

public RestauranteCAD(ISession sessionAux) : base (sessionAux)
{
}



public RestauranteEN ReadOIDDefault (int id
                                     )
{
        RestauranteEN restauranteEN = null;

        try
        {
                SessionInitializeTransaction ();
                restauranteEN = (RestauranteEN)session.Get (typeof(RestauranteEN), id);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return restauranteEN;
}

public System.Collections.Generic.IList<RestauranteEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<RestauranteEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(RestauranteEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<RestauranteEN>();
                        else
                                result = session.CreateCriteria (typeof(RestauranteEN)).List<RestauranteEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (RestauranteEN restaurante)
{
        try
        {
                SessionInitializeTransaction ();
                RestauranteEN restauranteEN = (RestauranteEN)session.Load (typeof(RestauranteEN), restaurante.Id);

                restauranteEN.Nombre = restaurante.Nombre;


                restauranteEN.Fecha_apertura = restaurante.Fecha_apertura;


                restauranteEN.Ciudad = restaurante.Ciudad;


                restauranteEN.Cod_pos = restaurante.Cod_pos;


                restauranteEN.Calle = restaurante.Calle;





                session.Update (restauranteEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int New_ (RestauranteEN restaurante)
{
        try
        {
                SessionInitializeTransaction ();
                if (restaurante.HorarioSemana != null) {
                        // Argumento OID y no colección.
                        restaurante.HorarioSemana = (LePapeoGenNHibernate.EN.LePapeo.HorarioSemanaEN)session.Load (typeof(LePapeoGenNHibernate.EN.LePapeo.HorarioSemanaEN), restaurante.HorarioSemana.Id);

                        restaurante.HorarioSemana.Restaurante
                        .Add (restaurante);
                }

                session.Save (restaurante);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return restaurante.Id;
}

public void Modify (RestauranteEN restaurante)
{
        try
        {
                SessionInitializeTransaction ();
                RestauranteEN restauranteEN = (RestauranteEN)session.Load (typeof(RestauranteEN), restaurante.Id);

                restauranteEN.Password = restaurante.Password;


                restauranteEN.Email = restaurante.Email;


                restauranteEN.Nombre = restaurante.Nombre;


                restauranteEN.Fecha_apertura = restaurante.Fecha_apertura;


                restauranteEN.Ciudad = restaurante.Ciudad;


                restauranteEN.Cod_pos = restaurante.Cod_pos;


                restauranteEN.Calle = restaurante.Calle;

                session.Update (restauranteEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}
public void Destroy (int id
                     )
{
        try
        {
                SessionInitializeTransaction ();
                RestauranteEN restauranteEN = (RestauranteEN)session.Load (typeof(RestauranteEN), id);
                session.Delete (restauranteEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}

//Sin e: ReadOID
//Con e: RestauranteEN
public RestauranteEN ReadOID (int id
                              )
{
        RestauranteEN restauranteEN = null;

        try
        {
                SessionInitializeTransaction ();
                restauranteEN = (RestauranteEN)session.Get (typeof(RestauranteEN), id);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return restauranteEN;
}

public System.Collections.Generic.IList<RestauranteEN> ReadAll (int first, int size)
{
        System.Collections.Generic.IList<RestauranteEN> result = null;
        try
        {
                SessionInitializeTransaction ();
                if (size > 0)
                        result = session.CreateCriteria (typeof(RestauranteEN)).
                                 SetFirstResult (first).SetMaxResults (size).List<RestauranteEN>();
                else
                        result = session.CreateCriteria (typeof(RestauranteEN)).List<RestauranteEN>();
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in RestauranteCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return result;
}
}
}
