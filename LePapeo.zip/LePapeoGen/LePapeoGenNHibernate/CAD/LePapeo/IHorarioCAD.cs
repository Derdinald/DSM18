
using System;
using LePapeoGenNHibernate.EN.LePapeo;

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial interface IHorarioCAD
{
HorarioEN ReadOIDDefault (int id
                          );

void ModifyDefault (HorarioEN horario);

System.Collections.Generic.IList<HorarioEN> ReadAllDefault (int first, int size);



int New_ (HorarioEN horario);
}
}
