
using System;
using System.Text;
using LePapeoGenNHibernate.CEN.LePapeo;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.Exceptions;


/*
 * Clase Horario:
 *
 */

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial class HorarioCAD : BasicCAD, IHorarioCAD
{
public HorarioCAD() : base ()
{
}

public HorarioCAD(ISession sessionAux) : base (sessionAux)
{
}



public HorarioEN ReadOIDDefault (int id
                                 )
{
        HorarioEN horarioEN = null;

        try
        {
                SessionInitializeTransaction ();
                horarioEN = (HorarioEN)session.Get (typeof(HorarioEN), id);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return horarioEN;
}

public System.Collections.Generic.IList<HorarioEN> ReadAllDefault (int first, int size)
{
        System.Collections.Generic.IList<HorarioEN> result = null;
        try
        {
                using (ITransaction tx = session.BeginTransaction ())
                {
                        if (size > 0)
                                result = session.CreateCriteria (typeof(HorarioEN)).
                                         SetFirstResult (first).SetMaxResults (size).List<HorarioEN>();
                        else
                                result = session.CreateCriteria (typeof(HorarioEN)).List<HorarioEN>();
                }
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioCAD.", ex);
        }

        return result;
}

// Modify default (Update all attributes of the class)

public void ModifyDefault (HorarioEN horario)
{
        try
        {
                SessionInitializeTransaction ();
                HorarioEN horarioEN = (HorarioEN)session.Load (typeof(HorarioEN), horario.Id);

                horarioEN.Dias = horario.Dias;


                horarioEN.Date_ini = horario.Date_ini;


                horarioEN.Date_fin = horario.Date_fin;


                horarioEN.Attribute = horario.Attribute;

                session.Update (horarioEN);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }
}


public int New_ (HorarioEN horario)
{
        try
        {
                SessionInitializeTransaction ();

                session.Save (horario);
                SessionCommit ();
        }

        catch (Exception ex) {
                SessionRollBack ();
                if (ex is LePapeoGenNHibernate.Exceptions.ModelException)
                        throw ex;
                throw new LePapeoGenNHibernate.Exceptions.DataLayerException ("Error in HorarioCAD.", ex);
        }


        finally
        {
                SessionClose ();
        }

        return horario.Id;
}
}
}
