
using System;
using LePapeoGenNHibernate.EN.LePapeo;

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial interface IOpinionCAD
{
OpinionEN ReadOIDDefault (int id
                          );

void ModifyDefault (OpinionEN opinion);

System.Collections.Generic.IList<OpinionEN> ReadAllDefault (int first, int size);



int New_ (OpinionEN opinion);

void Modify (OpinionEN opinion);


void Destroy (int id
              );


OpinionEN ReadOID (int id
                   );


System.Collections.Generic.IList<OpinionEN> ReadAll (int first, int size);
}
}
