
using System;
using LePapeoGenNHibernate.EN.LePapeo;

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial interface IReservaCAD
{
ReservaEN ReadOIDDefault (int id
                          );

void ModifyDefault (ReservaEN reserva);

System.Collections.Generic.IList<ReservaEN> ReadAllDefault (int first, int size);



int New_ (ReservaEN reserva);

void Modify (ReservaEN reserva);


void Destroy (int id
              );



ReservaEN ReadOID (int id
                   );


System.Collections.Generic.IList<ReservaEN> ReadAll (int first, int size);
}
}
