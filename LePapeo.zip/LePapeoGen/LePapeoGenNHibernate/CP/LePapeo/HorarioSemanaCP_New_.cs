
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using System.Collections.Generic;
using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.CAD.LePapeo;
using LePapeoGenNHibernate.CEN.LePapeo;



/*PROTECTED REGION ID(usingLePapeoGenNHibernate.CP.LePapeo_HorarioSemana_new_) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace LePapeoGenNHibernate.CP.LePapeo
{
public partial class HorarioSemanaCP : BasicCP
{
public LePapeoGenNHibernate.EN.LePapeo.HorarioSemanaEN New_ (bool p_Lunes, bool p_Martes, bool p_Miercoles, bool p_Jueves, bool p_Viernes, bool p_Sabado, bool p_Domingo)
{
        /*PROTECTED REGION ID(LePapeoGenNHibernate.CP.LePapeo_HorarioSemana_new_) ENABLED START*/

        IHorarioSemanaCAD horarioSemanaCAD = null;
        HorarioSemanaCEN horarioSemanaCEN = null;

            HorarioDiaCAD horarioDiaCAD = null;
            HorarioDiaCEN lunes;
            HorarioDiaCEN martes;
            HorarioDiaCEN miercoles;
            HorarioDiaCEN jueves;
            HorarioDiaCEN viernes;
            HorarioDiaCEN sabado;
            HorarioDiaCEN domingo;


            LePapeoGenNHibernate.EN.LePapeo.HorarioSemanaEN result = null;


        try
        {
                SessionInitializeTransaction ();
                horarioSemanaCAD = new HorarioSemanaCAD (session);
                horarioSemanaCEN = new  HorarioSemanaCEN (horarioSemanaCAD);

                horarioDiaCAD = new HorarioDiaCAD(session);
                lunes = new HorarioDiaCEN(horarioDiaCAD);
                martes = new HorarioDiaCEN(horarioDiaCAD);
                miercoles = new HorarioDiaCEN(horarioDiaCAD);
                jueves = new HorarioDiaCEN(horarioDiaCAD);
                viernes = new HorarioDiaCEN(horarioDiaCAD);
                sabado = new HorarioDiaCEN(horarioDiaCAD);
                domingo = new HorarioDiaCEN(horarioDiaCAD);
       




                int oid;
                //Initialized HorarioSemanaEN
                HorarioSemanaEN horarioSemanaEN;
                horarioSemanaEN = new HorarioSemanaEN ();
                horarioSemanaEN.Lunes = p_Lunes;

                horarioSemanaEN.Martes = p_Martes;

                horarioSemanaEN.Miercoles = p_Miercoles;

                horarioSemanaEN.Jueves = p_Jueves;

                horarioSemanaEN.Viernes = p_Viernes;

                horarioSemanaEN.Sabado = p_Sabado;

                horarioSemanaEN.Domingo = p_Domingo;


                    




                //Call to HorarioSemanaCAD

                oid = horarioSemanaCAD.New_ (horarioSemanaEN);
                result = horarioSemanaCAD.ReadOIDDefault (oid);


                if (horarioSemanaEN.Lunes == true)
                {
                    lunes.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.lunes, oid);

                }
                if (horarioSemanaEN.Martes == true)
                {
                    martes.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.martes, oid);

                }
                if (horarioSemanaEN.Miercoles == true)
                {
                    miercoles.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.miercoles, oid);

                }
                if (horarioSemanaEN.Jueves == true)
                {
                    jueves.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.jueves, oid);

                }
                if (horarioSemanaEN.Viernes == true)
                {
                    viernes.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.viernes, oid);

                }
                if (horarioSemanaEN.Sabado == true)
                {
                    sabado.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.sabado, oid);

                }
                if (horarioSemanaEN.Domingo == true)
                {
                    domingo.New_(new DateTime(2001, 1, 1, 9, 0, 0), new DateTime(2001, 1, 1, 15, 30, 0), new DateTime(2001, 1, 1, 20, 0, 0), new DateTime(2001, 1, 1, 0, 0, 0), Enumerated.LePapeo.DiaSemanaEnum.domingo, oid);

                }

                SessionCommit ();
        }
        catch (Exception ex)
        {
                SessionRollBack ();
                throw ex;
        }
        finally
        {
                SessionClose ();
        }
        return result;


        /*PROTECTED REGION END*/
}
}
}
