
using System;
// Definición clase HorarioEN
namespace LePapeoGenNHibernate.EN.LePapeo
{
public partial class HorarioEN
{
/**
 *	Atributo dias
 */
private LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum dias;



/**
 *	Atributo date_ini
 */
private Nullable<DateTime> date_ini;



/**
 *	Atributo date_fin
 */
private Nullable<DateTime> date_fin;



/**
 *	Atributo attribute
 */
private string attribute;



/**
 *	Atributo id
 */
private int id;






public virtual LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum Dias {
        get { return dias; } set { dias = value;  }
}



public virtual Nullable<DateTime> Date_ini {
        get { return date_ini; } set { date_ini = value;  }
}



public virtual Nullable<DateTime> Date_fin {
        get { return date_fin; } set { date_fin = value;  }
}



public virtual string Attribute {
        get { return attribute; } set { attribute = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}





public HorarioEN()
{
}



public HorarioEN(int id, LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum dias, Nullable<DateTime> date_ini, Nullable<DateTime> date_fin, string attribute
                 )
{
        this.init (Id, dias, date_ini, date_fin, attribute);
}


public HorarioEN(HorarioEN horario)
{
        this.init (Id, horario.Dias, horario.Date_ini, horario.Date_fin, horario.Attribute);
}

private void init (int id
                   , LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum dias, Nullable<DateTime> date_ini, Nullable<DateTime> date_fin, string attribute)
{
        this.Id = id;


        this.Dias = dias;

        this.Date_ini = date_ini;

        this.Date_fin = date_fin;

        this.Attribute = attribute;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        HorarioEN t = obj as HorarioEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
