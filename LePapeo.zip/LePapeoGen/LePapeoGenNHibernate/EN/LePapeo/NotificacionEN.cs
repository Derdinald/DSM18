
using System;
// Definición clase NotificacionEN
namespace LePapeoGenNHibernate.EN.LePapeo
{
public partial class NotificacionEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo registrado
 */
private LePapeoGenNHibernate.EN.LePapeo.RegistradoEN registrado;



/**
 *	Atributo restaurante
 */
private LePapeoGenNHibernate.EN.LePapeo.RestauranteEN restaurante;



/**
 *	Atributo contenido
 */
private string contenido;



/**
 *	Atributo notificacionGenerica
 */
private LePapeoGenNHibernate.EN.LePapeo.NotificacionGenericaEN notificacionGenerica;



/**
 *	Atributo fecha
 */
private Nullable<DateTime> fecha;



/**
 *	Atributo enviada
 */
private bool enviada;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual LePapeoGenNHibernate.EN.LePapeo.RegistradoEN Registrado {
        get { return registrado; } set { registrado = value;  }
}



public virtual LePapeoGenNHibernate.EN.LePapeo.RestauranteEN Restaurante {
        get { return restaurante; } set { restaurante = value;  }
}



public virtual string Contenido {
        get { return contenido; } set { contenido = value;  }
}



public virtual LePapeoGenNHibernate.EN.LePapeo.NotificacionGenericaEN NotificacionGenerica {
        get { return notificacionGenerica; } set { notificacionGenerica = value;  }
}



public virtual Nullable<DateTime> Fecha {
        get { return fecha; } set { fecha = value;  }
}



public virtual bool Enviada {
        get { return enviada; } set { enviada = value;  }
}





public NotificacionEN()
{
}



public NotificacionEN(int id, LePapeoGenNHibernate.EN.LePapeo.RegistradoEN registrado, LePapeoGenNHibernate.EN.LePapeo.RestauranteEN restaurante, string contenido, LePapeoGenNHibernate.EN.LePapeo.NotificacionGenericaEN notificacionGenerica, Nullable<DateTime> fecha, bool enviada
                      )
{
        this.init (Id, registrado, restaurante, contenido, notificacionGenerica, fecha, enviada);
}


public NotificacionEN(NotificacionEN notificacion)
{
        this.init (Id, notificacion.Registrado, notificacion.Restaurante, notificacion.Contenido, notificacion.NotificacionGenerica, notificacion.Fecha, notificacion.Enviada);
}

private void init (int id
                   , LePapeoGenNHibernate.EN.LePapeo.RegistradoEN registrado, LePapeoGenNHibernate.EN.LePapeo.RestauranteEN restaurante, string contenido, LePapeoGenNHibernate.EN.LePapeo.NotificacionGenericaEN notificacionGenerica, Nullable<DateTime> fecha, bool enviada)
{
        this.Id = id;


        this.Registrado = registrado;

        this.Restaurante = restaurante;

        this.Contenido = contenido;

        this.NotificacionGenerica = notificacionGenerica;

        this.Fecha = fecha;

        this.Enviada = enviada;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        NotificacionEN t = obj as NotificacionEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
