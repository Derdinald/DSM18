
using System;
// Definición clase HorarioSemanaEN
namespace LePapeoGenNHibernate.EN.LePapeo
{
public partial class HorarioSemanaEN
{
/**
 *	Atributo lunes
 */
private bool lunes;



/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo martes
 */
private bool martes;



/**
 *	Atributo miercoles
 */
private bool miercoles;



/**
 *	Atributo jueves
 */
private bool jueves;



/**
 *	Atributo viernes
 */
private bool viernes;



/**
 *	Atributo sabado
 */
private bool sabado;



/**
 *	Atributo domingo
 */
private bool domingo;



/**
 *	Atributo horarioDia
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.HorarioDiaEN> horarioDia;



/**
 *	Atributo restaurante
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.RestauranteEN> restaurante;






public virtual bool Lunes {
        get { return lunes; } set { lunes = value;  }
}



public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual bool Martes {
        get { return martes; } set { martes = value;  }
}



public virtual bool Miercoles {
        get { return miercoles; } set { miercoles = value;  }
}



public virtual bool Jueves {
        get { return jueves; } set { jueves = value;  }
}



public virtual bool Viernes {
        get { return viernes; } set { viernes = value;  }
}



public virtual bool Sabado {
        get { return sabado; } set { sabado = value;  }
}



public virtual bool Domingo {
        get { return domingo; } set { domingo = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.HorarioDiaEN> HorarioDia {
        get { return horarioDia; } set { horarioDia = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.RestauranteEN> Restaurante {
        get { return restaurante; } set { restaurante = value;  }
}





public HorarioSemanaEN()
{
        horarioDia = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.HorarioDiaEN>();
        restaurante = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.RestauranteEN>();
}



public HorarioSemanaEN(int id, bool lunes, bool martes, bool miercoles, bool jueves, bool viernes, bool sabado, bool domingo, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.HorarioDiaEN> horarioDia, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.RestauranteEN> restaurante
                       )
{
        this.init (Id, lunes, martes, miercoles, jueves, viernes, sabado, domingo, horarioDia, restaurante);
}


public HorarioSemanaEN(HorarioSemanaEN horarioSemana)
{
        this.init (Id, horarioSemana.Lunes, horarioSemana.Martes, horarioSemana.Miercoles, horarioSemana.Jueves, horarioSemana.Viernes, horarioSemana.Sabado, horarioSemana.Domingo, horarioSemana.HorarioDia, horarioSemana.Restaurante);
}

private void init (int id
                   , bool lunes, bool martes, bool miercoles, bool jueves, bool viernes, bool sabado, bool domingo, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.HorarioDiaEN> horarioDia, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.RestauranteEN> restaurante)
{
        this.Id = id;


        this.Lunes = lunes;

        this.Martes = martes;

        this.Miercoles = miercoles;

        this.Jueves = jueves;

        this.Viernes = viernes;

        this.Sabado = sabado;

        this.Domingo = domingo;

        this.HorarioDia = horarioDia;

        this.Restaurante = restaurante;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        HorarioSemanaEN t = obj as HorarioSemanaEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
