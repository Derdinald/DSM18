
using System;
// Definición clase RestauranteEN
namespace LePapeoGenNHibernate.EN.LePapeo
{
public partial class RestauranteEN                                                                  : LePapeoGenNHibernate.EN.LePapeo.UsuarioEN


{
/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo fecha_apertura
 */
private Nullable<DateTime> fecha_apertura;



/**
 *	Atributo ciudad
 */
private string ciudad;



/**
 *	Atributo cod_pos
 */
private int cod_pos;



/**
 *	Atributo calle
 */
private string calle;



/**
 *	Atributo reserva_0
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> reserva_0;



/**
 *	Atributo opinion_0
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> opinion_0;



/**
 *	Atributo notificacion_0
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> notificacion_0;






public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual Nullable<DateTime> Fecha_apertura {
        get { return fecha_apertura; } set { fecha_apertura = value;  }
}



public virtual string Ciudad {
        get { return ciudad; } set { ciudad = value;  }
}



public virtual int Cod_pos {
        get { return cod_pos; } set { cod_pos = value;  }
}



public virtual string Calle {
        get { return calle; } set { calle = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> Reserva_0 {
        get { return reserva_0; } set { reserva_0 = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> Opinion_0 {
        get { return opinion_0; } set { opinion_0 = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> Notificacion_0 {
        get { return notificacion_0; } set { notificacion_0 = value;  }
}





public RestauranteEN() : base ()
{
        reserva_0 = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.ReservaEN>();
        opinion_0 = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.OpinionEN>();
        notificacion_0 = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN>();
}



public RestauranteEN(int id, string nombre, Nullable<DateTime> fecha_apertura, string ciudad, int cod_pos, string calle, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> reserva_0, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> opinion_0, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> notificacion_0
                     , String password, string email
                     )
{
        this.init (Id, nombre, fecha_apertura, ciudad, cod_pos, calle, reserva_0, opinion_0, notificacion_0, password, email);
}


public RestauranteEN(RestauranteEN restaurante)
{
        this.init (Id, restaurante.Nombre, restaurante.Fecha_apertura, restaurante.Ciudad, restaurante.Cod_pos, restaurante.Calle, restaurante.Reserva_0, restaurante.Opinion_0, restaurante.Notificacion_0, restaurante.Password, restaurante.Email);
}

private void init (int id
                   , string nombre, Nullable<DateTime> fecha_apertura, string ciudad, int cod_pos, string calle, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> reserva_0, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> opinion_0, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> notificacion_0, String password, string email)
{
        this.Id = id;


        this.Nombre = nombre;

        this.Fecha_apertura = fecha_apertura;

        this.Ciudad = ciudad;

        this.Cod_pos = cod_pos;

        this.Calle = calle;

        this.Reserva_0 = reserva_0;

        this.Opinion_0 = opinion_0;

        this.Notificacion_0 = notificacion_0;

        this.Password = password;

        this.Email = email;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        RestauranteEN t = obj as RestauranteEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
