

using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.Exceptions;

using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.CAD.LePapeo;


namespace LePapeoGenNHibernate.CEN.LePapeo
{
/*
 *      Definition of the class HorarioSemanaCEN
 *
 */
public partial class HorarioSemanaCEN
{
private IHorarioSemanaCAD _IHorarioSemanaCAD;

public HorarioSemanaCEN()
{
        this._IHorarioSemanaCAD = new HorarioSemanaCAD ();
}

public HorarioSemanaCEN(IHorarioSemanaCAD _IHorarioSemanaCAD)
{
        this._IHorarioSemanaCAD = _IHorarioSemanaCAD;
}

public IHorarioSemanaCAD get_IHorarioSemanaCAD ()
{
        return this._IHorarioSemanaCAD;
}

public void Modify (int p_HorarioSemana_OID, bool p_Lunes, bool p_Martes, bool p_Miercoles, bool p_Jueves, bool p_Viernes, bool p_Sabado, bool p_Domingo)
{
        HorarioSemanaEN horarioSemanaEN = null;

        //Initialized HorarioSemanaEN
        horarioSemanaEN = new HorarioSemanaEN ();
        horarioSemanaEN.Id = p_HorarioSemana_OID;
        horarioSemanaEN.Lunes = p_Lunes;
        horarioSemanaEN.Martes = p_Martes;
        horarioSemanaEN.Miercoles = p_Miercoles;
        horarioSemanaEN.Jueves = p_Jueves;
        horarioSemanaEN.Viernes = p_Viernes;
        horarioSemanaEN.Sabado = p_Sabado;
        horarioSemanaEN.Domingo = p_Domingo;
        //Call to HorarioSemanaCAD

        _IHorarioSemanaCAD.Modify (horarioSemanaEN);
}

public void Destroy (int id
                     )
{
        _IHorarioSemanaCAD.Destroy (id);
}
}
}
