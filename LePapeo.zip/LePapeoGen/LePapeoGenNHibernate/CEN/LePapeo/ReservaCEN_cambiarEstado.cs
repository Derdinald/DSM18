
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.Exceptions;
using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.CAD.LePapeo;


/*PROTECTED REGION ID(usingLePapeoGenNHibernate.CEN.LePapeo_Reserva_cambiarEstado) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace LePapeoGenNHibernate.CEN.LePapeo
{
public partial class ReservaCEN
{
public void CambiarEstado (int p_oid)
{
        /*PROTECTED REGION ID(LePapeoGenNHibernate.CEN.LePapeo_Reserva_cambiarEstado) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method CambiarEstado() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
