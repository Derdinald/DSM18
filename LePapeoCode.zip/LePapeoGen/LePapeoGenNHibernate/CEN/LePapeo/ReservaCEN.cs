

using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.Exceptions;

using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.CAD.LePapeo;


namespace LePapeoGenNHibernate.CEN.LePapeo
{
/*
 *      Definition of the class ReservaCEN
 *
 */
public partial class ReservaCEN
{
private IReservaCAD _IReservaCAD;

public ReservaCEN()
{
        this._IReservaCAD = new ReservaCAD ();
}

public ReservaCEN(IReservaCAD _IReservaCAD)
{
        this._IReservaCAD = _IReservaCAD;
}

public IReservaCAD get_IReservaCAD ()
{
        return this._IReservaCAD;
}

public int New_ (int p_registrado, int p_restaurante, int p_comensales, LePapeoGenNHibernate.Enumerated.LePapeo.HorasEnum p_hora, LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum p_dia, LePapeoGenNHibernate.Enumerated.LePapeo.EstadoReservaEnum p_estado, bool p_finalizada)
{
        ReservaEN reservaEN = null;
        int oid;

        //Initialized ReservaEN
        reservaEN = new ReservaEN ();

        if (p_registrado != -1) {
                // El argumento p_registrado -> Property registrado es oid = false
                // Lista de oids id
                reservaEN.Registrado = new LePapeoGenNHibernate.EN.LePapeo.RegistradoEN ();
                reservaEN.Registrado.Id = p_registrado;
        }


        if (p_restaurante != -1) {
                // El argumento p_restaurante -> Property restaurante es oid = false
                // Lista de oids id
                reservaEN.Restaurante = new LePapeoGenNHibernate.EN.LePapeo.RestauranteEN ();
                reservaEN.Restaurante.Id = p_restaurante;
        }

        reservaEN.Comensales = p_comensales;

        reservaEN.Hora = p_hora;

        reservaEN.Dia = p_dia;

        reservaEN.Estado = p_estado;

        reservaEN.Finalizada = p_finalizada;

        //Call to ReservaCAD

        oid = _IReservaCAD.New_ (reservaEN);
        return oid;
}

public void Modify (int p_Reserva_OID, int p_comensales, LePapeoGenNHibernate.Enumerated.LePapeo.HorasEnum p_hora, LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum p_dia, LePapeoGenNHibernate.Enumerated.LePapeo.EstadoReservaEnum p_estado, bool p_finalizada)
{
        ReservaEN reservaEN = null;

        //Initialized ReservaEN
        reservaEN = new ReservaEN ();
        reservaEN.Id = p_Reserva_OID;
        reservaEN.Comensales = p_comensales;
        reservaEN.Hora = p_hora;
        reservaEN.Dia = p_dia;
        reservaEN.Estado = p_estado;
        reservaEN.Finalizada = p_finalizada;
        //Call to ReservaCAD

        _IReservaCAD.Modify (reservaEN);
}

public void Destroy (int id
                     )
{
        _IReservaCAD.Destroy (id);
}

public ReservaEN ReadOID (int id
                          )
{
        ReservaEN reservaEN = null;

        reservaEN = _IReservaCAD.ReadOID (id);
        return reservaEN;
}

public System.Collections.Generic.IList<ReservaEN> ReadAll (int first, int size)
{
        System.Collections.Generic.IList<ReservaEN> list = null;

        list = _IReservaCAD.ReadAll (first, size);
        return list;
}
}
}
