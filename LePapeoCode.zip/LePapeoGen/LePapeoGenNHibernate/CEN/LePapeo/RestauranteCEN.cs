

using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.Exceptions;

using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.CAD.LePapeo;


namespace LePapeoGenNHibernate.CEN.LePapeo
{
/*
 *      Definition of the class RestauranteCEN
 *
 */
public partial class RestauranteCEN
{
private IRestauranteCAD _IRestauranteCAD;

public RestauranteCEN()
{
        this._IRestauranteCAD = new RestauranteCAD ();
}

public RestauranteCEN(IRestauranteCAD _IRestauranteCAD)
{
        this._IRestauranteCAD = _IRestauranteCAD;
}

public IRestauranteCAD get_IRestauranteCAD ()
{
        return this._IRestauranteCAD;
}

public int New_ (String p_password, string p_email, string p_nombre, Nullable<DateTime> p_fecha_apertura, string p_ciudad, int p_cod_pos, string p_calle)
{
        RestauranteEN restauranteEN = null;
        int oid;

        //Initialized RestauranteEN
        restauranteEN = new RestauranteEN ();
        restauranteEN.Password = Utils.Util.GetEncondeMD5 (p_password);

        restauranteEN.Email = p_email;

        restauranteEN.Nombre = p_nombre;

        restauranteEN.Fecha_apertura = p_fecha_apertura;

        restauranteEN.Ciudad = p_ciudad;

        restauranteEN.Cod_pos = p_cod_pos;

        restauranteEN.Calle = p_calle;

        //Call to RestauranteCAD

        oid = _IRestauranteCAD.New_ (restauranteEN);
        return oid;
}

public void Modify (int p_Restaurante_OID, String p_password, string p_email, string p_nombre, Nullable<DateTime> p_fecha_apertura, string p_ciudad, int p_cod_pos, string p_calle)
{
        RestauranteEN restauranteEN = null;

        //Initialized RestauranteEN
        restauranteEN = new RestauranteEN ();
        restauranteEN.Id = p_Restaurante_OID;
        restauranteEN.Password = Utils.Util.GetEncondeMD5 (p_password);
        restauranteEN.Email = p_email;
        restauranteEN.Nombre = p_nombre;
        restauranteEN.Fecha_apertura = p_fecha_apertura;
        restauranteEN.Ciudad = p_ciudad;
        restauranteEN.Cod_pos = p_cod_pos;
        restauranteEN.Calle = p_calle;
        //Call to RestauranteCAD

        _IRestauranteCAD.Modify (restauranteEN);
}

public void Destroy (int id
                     )
{
        _IRestauranteCAD.Destroy (id);
}

public RestauranteEN ReadOID (int id
                              )
{
        RestauranteEN restauranteEN = null;

        restauranteEN = _IRestauranteCAD.ReadOID (id);
        return restauranteEN;
}

public System.Collections.Generic.IList<RestauranteEN> ReadAll (int first, int size)
{
        System.Collections.Generic.IList<RestauranteEN> list = null;

        list = _IRestauranteCAD.ReadAll (first, size);
        return list;
}
}
}
