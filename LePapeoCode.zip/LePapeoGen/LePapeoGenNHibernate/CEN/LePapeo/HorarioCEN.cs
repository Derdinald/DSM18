

using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using LePapeoGenNHibernate.Exceptions;

using LePapeoGenNHibernate.EN.LePapeo;
using LePapeoGenNHibernate.CAD.LePapeo;


namespace LePapeoGenNHibernate.CEN.LePapeo
{
/*
 *      Definition of the class HorarioCEN
 *
 */
public partial class HorarioCEN
{
private IHorarioCAD _IHorarioCAD;

public HorarioCEN()
{
        this._IHorarioCAD = new HorarioCAD ();
}

public HorarioCEN(IHorarioCAD _IHorarioCAD)
{
        this._IHorarioCAD = _IHorarioCAD;
}

public IHorarioCAD get_IHorarioCAD ()
{
        return this._IHorarioCAD;
}

public int New_ (LePapeoGenNHibernate.Enumerated.LePapeo.DiasEnum p_dias, Nullable<DateTime> p_date_ini, Nullable<DateTime> p_date_fin, string p_attribute)
{
        HorarioEN horarioEN = null;
        int oid;

        //Initialized HorarioEN
        horarioEN = new HorarioEN ();
        horarioEN.Dias = p_dias;

        horarioEN.Date_ini = p_date_ini;

        horarioEN.Date_fin = p_date_fin;

        horarioEN.Attribute = p_attribute;

        //Call to HorarioCAD

        oid = _IHorarioCAD.New_ (horarioEN);
        return oid;
}
}
}
