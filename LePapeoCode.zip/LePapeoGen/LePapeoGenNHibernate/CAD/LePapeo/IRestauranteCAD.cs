
using System;
using LePapeoGenNHibernate.EN.LePapeo;

namespace LePapeoGenNHibernate.CAD.LePapeo
{
public partial interface IRestauranteCAD
{
RestauranteEN ReadOIDDefault (int id
                              );

void ModifyDefault (RestauranteEN restaurante);

System.Collections.Generic.IList<RestauranteEN> ReadAllDefault (int first, int size);



int New_ (RestauranteEN restaurante);

void Modify (RestauranteEN restaurante);


void Destroy (int id
              );


RestauranteEN ReadOID (int id
                       );


System.Collections.Generic.IList<RestauranteEN> ReadAll (int first, int size);
}
}
