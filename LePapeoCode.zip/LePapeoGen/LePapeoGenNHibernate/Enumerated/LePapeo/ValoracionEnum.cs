
using System;

namespace LePapeoGenNHibernate.Enumerated.LePapeo
{
public enum ValoracionEnum { muy_baja=1, baja=2, media=3, alta=4, muy_alta=5 };
}
