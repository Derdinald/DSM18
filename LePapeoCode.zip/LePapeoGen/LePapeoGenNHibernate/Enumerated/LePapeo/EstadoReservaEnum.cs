
using System;

namespace LePapeoGenNHibernate.Enumerated.LePapeo
{
public enum EstadoReservaEnum { pendiente=0, aceptada=1, cancelada=2 };
}
