
using System;
// Definición clase RegistradoEN
namespace LePapeoGenNHibernate.EN.LePapeo
{
public partial class RegistradoEN                                                                   : LePapeoGenNHibernate.EN.LePapeo.UsuarioEN


{
/**
 *	Atributo nombre
 */
private string nombre;



/**
 *	Atributo apellidos
 */
private string apellidos;



/**
 *	Atributo fecha_nac
 */
private Nullable<DateTime> fecha_nac;



/**
 *	Atributo ciudad
 */
private string ciudad;



/**
 *	Atributo cod_pos
 */
private int cod_pos;



/**
 *	Atributo calle
 */
private string calle;



/**
 *	Atributo reserva
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> reserva;



/**
 *	Atributo opinion
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> opinion;



/**
 *	Atributo notificacion
 */
private System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> notificacion;






public virtual string Nombre {
        get { return nombre; } set { nombre = value;  }
}



public virtual string Apellidos {
        get { return apellidos; } set { apellidos = value;  }
}



public virtual Nullable<DateTime> Fecha_nac {
        get { return fecha_nac; } set { fecha_nac = value;  }
}



public virtual string Ciudad {
        get { return ciudad; } set { ciudad = value;  }
}



public virtual int Cod_pos {
        get { return cod_pos; } set { cod_pos = value;  }
}



public virtual string Calle {
        get { return calle; } set { calle = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> Reserva {
        get { return reserva; } set { reserva = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> Opinion {
        get { return opinion; } set { opinion = value;  }
}



public virtual System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> Notificacion {
        get { return notificacion; } set { notificacion = value;  }
}





public RegistradoEN() : base ()
{
        reserva = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.ReservaEN>();
        opinion = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.OpinionEN>();
        notificacion = new System.Collections.Generic.List<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN>();
}



public RegistradoEN(int id, string nombre, string apellidos, Nullable<DateTime> fecha_nac, string ciudad, int cod_pos, string calle, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> reserva, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> opinion, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> notificacion
                    , String password, string email
                    )
{
        this.init (Id, nombre, apellidos, fecha_nac, ciudad, cod_pos, calle, reserva, opinion, notificacion, password, email);
}


public RegistradoEN(RegistradoEN registrado)
{
        this.init (Id, registrado.Nombre, registrado.Apellidos, registrado.Fecha_nac, registrado.Ciudad, registrado.Cod_pos, registrado.Calle, registrado.Reserva, registrado.Opinion, registrado.Notificacion, registrado.Password, registrado.Email);
}

private void init (int id
                   , string nombre, string apellidos, Nullable<DateTime> fecha_nac, string ciudad, int cod_pos, string calle, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.ReservaEN> reserva, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.OpinionEN> opinion, System.Collections.Generic.IList<LePapeoGenNHibernate.EN.LePapeo.NotificacionEN> notificacion, String password, string email)
{
        this.Id = id;


        this.Nombre = nombre;

        this.Apellidos = apellidos;

        this.Fecha_nac = fecha_nac;

        this.Ciudad = ciudad;

        this.Cod_pos = cod_pos;

        this.Calle = calle;

        this.Reserva = reserva;

        this.Opinion = opinion;

        this.Notificacion = notificacion;

        this.Password = password;

        this.Email = email;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        RegistradoEN t = obj as RegistradoEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
