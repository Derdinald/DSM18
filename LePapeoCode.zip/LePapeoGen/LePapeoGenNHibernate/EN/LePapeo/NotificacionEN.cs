
using System;
// Definición clase NotificacionEN
namespace LePapeoGenNHibernate.EN.LePapeo
{
public partial class NotificacionEN
{
/**
 *	Atributo id
 */
private int id;



/**
 *	Atributo registrado
 */
private LePapeoGenNHibernate.EN.LePapeo.RegistradoEN registrado;



/**
 *	Atributo restaurante
 */
private LePapeoGenNHibernate.EN.LePapeo.RestauranteEN restaurante;



/**
 *	Atributo contenido
 */
private string contenido;






public virtual int Id {
        get { return id; } set { id = value;  }
}



public virtual LePapeoGenNHibernate.EN.LePapeo.RegistradoEN Registrado {
        get { return registrado; } set { registrado = value;  }
}



public virtual LePapeoGenNHibernate.EN.LePapeo.RestauranteEN Restaurante {
        get { return restaurante; } set { restaurante = value;  }
}



public virtual string Contenido {
        get { return contenido; } set { contenido = value;  }
}





public NotificacionEN()
{
}



public NotificacionEN(int id, LePapeoGenNHibernate.EN.LePapeo.RegistradoEN registrado, LePapeoGenNHibernate.EN.LePapeo.RestauranteEN restaurante, string contenido
                      )
{
        this.init (Id, registrado, restaurante, contenido);
}


public NotificacionEN(NotificacionEN notificacion)
{
        this.init (Id, notificacion.Registrado, notificacion.Restaurante, notificacion.Contenido);
}

private void init (int id
                   , LePapeoGenNHibernate.EN.LePapeo.RegistradoEN registrado, LePapeoGenNHibernate.EN.LePapeo.RestauranteEN restaurante, string contenido)
{
        this.Id = id;


        this.Registrado = registrado;

        this.Restaurante = restaurante;

        this.Contenido = contenido;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        NotificacionEN t = obj as NotificacionEN;
        if (t == null)
                return false;
        if (Id.Equals (t.Id))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Id.GetHashCode ();
        return hash;
}
}
}
